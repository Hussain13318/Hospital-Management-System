#include <iostream>
#include <vector>
#include <string>
#include "Patient_Handler.h"
#include "Doctor_Handler.h"
#include "Appoinment_Handler.h"
#include "Recomendation_System.h"
#include "Billing_Handler.h" // Include your new billing header

using namespace std;

int main() {
    cout << "--- Hospital Management System: Backend Test ---" << endl;

    // 1. Setup Handlers
    Doctor_handler dh;
    dh.read_from_file();
    
    Patient_Handler ph;
    ph.load_OPD("archive/opd.csv");
    ph.load_Emergency("archive/emergency.csv");

    Recom_System rs;
    rs.load_data("archive/symptoms.csv", "archive/precautions.csv", "archive/disease_med.csv");

    Billing_Handler bh;
    bh.load_medicine_prices(); // Ensure archive/medicines.csv exists

    // 2. Test Billing for an OPD Patient
    cout << "\n[5] Testing OPD Billing:" << endl;
    
    // Create a dummy OPD patient for testing
    OPD_Patient opd_p=ph.accessOPDByID("O008");
    // Assume cardiology fee is 1500
    bh.create_opd_bill(opd_p, 1500); 
    
    // Simulate adding medicine from recommendation system
    bh.add_medicine_to_bill("O008", "Aspirin", 2); 
    bh.add_custom_charge("O008", "ECG Test", 500);
    
    bh.print_bill("O008");

    // 3. Test Billing for an Emergency Patient
    cout << "\n[6] Testing Emergency Billing:" << endl;
    
    // Create a dummy Emergency patient
    Emergency_Patient em_p=ph.accessEmByID("E001"); // High severity
    
    // Create bill with a base fee of 2000
    bh.create_emergency_bill(em_p, 2000); 
    
    // Add specialized emergency services
    bh.add_custom_charge("E001", "Oxygen Support", 1200);
    
    bh.print_bill("E001");

    // 4. Save and Finalize
    cout << "[7] Finalizing and Saving Bills..." << endl;
    bh.mark_as_paid("O008");
    bh.save_bills_to_file(); // Save to archive/bills.csv
    cout << "Billing data saved successfully." << endl;

    cout << "\n--- All Tests Complete ---" << endl;
    return 0;
}