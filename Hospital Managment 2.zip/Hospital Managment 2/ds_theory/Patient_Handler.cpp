
#include "Patient_Handler.h"

    

void Patient_Handler::load_OPD(string filename)
    {
        ifstream file(filename);
        string line;
        getline(file, line); // skip header
        while (getline(file, line))
        {
            stringstream ss(line);
            string id, name, age, blood, gender, contact, dept;
            getline(ss, id, ','); 
            getline(ss, name, ','); 
            getline(ss, age, ',');
            getline(ss, blood, ','); 
            getline(ss, gender, ','); 
            getline(ss, contact, ','); 
            getline(ss, dept, ',');

            OPD_Patient p;
            p.id = id; 
            p.name = name; 
            p.age = stoi(age);
             p.blood = blood;
            p.gender = gender; 
            p.contact_number = contact;
            p.department = dept;
            opd_patients[id] = p;
            opd_queue.push(p);
        }
        file.close();
    }

    void Patient_Handler::load_Emergency(string filename)
    {
        ifstream file(filename);
        string line;
        getline(file, line); // skip header
        while (getline(file, line))
        {
            stringstream ss(line);
            string id, name, age, blood, gender, relative, sens;
            string vals[10];
            getline(ss, id, ',');
            getline(ss, name, ','); 
            getline(ss, age, ',');
            getline(ss, blood, ','); 
            getline(ss, gender, ','); 
            getline(ss, relative, ','); 
            getline(ss, sens, ',');
            for (int i = 0; i < 10; i++) 
            {
                getline(ss, vals[i], ',');
            }

            Emergency_Patient p;
            p.id = id; p.name = name; p.age = stoi(age); p.blood = blood; p.gender = gender;
            p.relative_number = relative; p.sensitivity = stoi(sens); p.arrivalIndex = emergencyIndex++;
            p.symptoms.bloodPressure = stoi(vals[0]); p.symptoms.heartRate = stoi(vals[1]);
            p.symptoms.oxygenLevel = stoi(vals[2]); p.symptoms.temperature = stoi(vals[3]);
            p.symptoms.respiratoryRate = stoi(vals[4]); p.symptoms.consciousness = stoi(vals[5]);
            p.symptoms.bleeding = stoi(vals[6]); p.symptoms.pain = stoi(vals[7]);
            p.symptoms.chestPain = stoi(vals[8]); p.symptoms.nausea = stoi(vals[9]);

            emergency_patients[id] = p;
            emergency_queue.push(p);
        }
        file.close();
    }

    // ---------- Treat Patients ----------
    void Patient_Handler::treat_OPD()
    {
        if (!opd_queue.empty())
        {
            OPD_Patient p = opd_queue.front();
            opd_queue.pop();
            cout << "OPD patient treated: " << p.name << " | Department: " << p.department << endl;
        }
        else 
        {
            cout << "No OPD patients.\n";
        }
    }

    void Patient_Handler::treat_Emergency()
    {
        if (!emergency_queue.empty())
        {
            Emergency_Patient p = emergency_queue.top();
            emergency_queue.pop();
            cout << "Emergency patient treated: " << p.name << " | Sensitivity: " << p.sensitivity << endl;
        }
        else 
        {
            cout << "No Emergency patients.\n";
        }
    }

    // ---------- Add Patients ----------
    void Patient_Handler::add_OPD_patient(const OPD_Patient& p)
    {
        opd_patients[p.id] = p;
        opd_queue.push(p);
        write_OPD_file("OPD.csv", opd_patients);
        cout << "OPD patient added: " << p.name << endl;
    }

    void Patient_Handler::add_Emergency_patient(Emergency_Patient p)
    {
        p.arrivalIndex = emergencyIndex++;
        emergency_patients[p.id] = p;
        emergency_queue.push(p);
        write_Emergency_file("Emergency.csv", emergency_patients);
        cout << "Emergency patient added: " << p.name << endl;
    }

    // ---------- Write CSVs ----------
    void Patient_Handler::write_OPD_file(const string& filename, map<string, OPD_Patient>& patients)
    {
        ofstream file(filename);
        file << "patient_id,name,age,blood,gender,contact_number,department\n";
        for (auto& i : patients)
        {
            OPD_Patient& p = i.second;
            file << p.id << "," << p.name << "," << p.age << "," << p.blood << "," << p.gender << "," << p.contact_number << "," << p.department << "\n";
        }
        file.close();
    }

    void Patient_Handler::write_Emergency_file(const string& filename, map<string, Emergency_Patient>& patients)
    {
        ofstream file(filename);
        file << "patient_id,name,age,blood,gender,relative_number,sensitivity,bloodPressure,heartRate,oxygenLevel,temperature,respiratoryRate,consciousness,bleeding,pain,chestPain,nausea\n";
        for (auto& i : patients)
        {
            Emergency_Patient& p = i.second;
            file << p.id << "," << p.name << "," << p.age << "," 
                 << p.blood << "," << p.gender << "," << p.relative_number << "," 
                 << p.sensitivity << ","
                 << p.symptoms.bloodPressure << "," << p.symptoms.heartRate << ","
                 << p.symptoms.oxygenLevel << "," << p.symptoms.temperature << ","
                 << p.symptoms.respiratoryRate << "," << p.symptoms.consciousness << ","
                 << p.symptoms.bleeding << "," << p.symptoms.pain << ","
                 << p.symptoms.chestPain << "," << p.symptoms.nausea << "\n";
        }
        file.close();
    }


    Emergency_Patient Patient_Handler::accessEmByID(string p_id)
    {
        if (emergency_patients.count(p_id) == 0)
            cout << "Patient Dont Exist" << "\n";
        else
            return emergency_patients[p_id];
        return Emergency_Patient();
    }

    OPD_Patient Patient_Handler::accessOPDByID(string p_id)
    {   
        if (opd_patients.count(p_id) == 0)
            cout << "Patient Dont Exist" << "\n";
        else
            return opd_patients[p_id];
        return OPD_Patient();
    }