#include "backend.h"



Doctor Doctor_handler::getdoctorbyid(const string& doctor_id) {
    if (doctors.find(doctor_id) != doctors.end()) {
        return doctors[doctor_id];
    }
    return Doctor();
}

void Doctor_handler::read_from_file()
{
    ifstream file(filename);
    string wholeline;
    int row = 0;
    Doctor temp;
    string years_exp_str;
	string available_str;
    while (getline(file, wholeline))
    {
        if (row == 0)
        {
            row++;
            continue;
        }

        stringstream line(wholeline);
        getline(line, temp.doctor_id, ',');
		getline(line, temp.first_name, ',');
		getline(line, temp.last_name, ',');
		getline(line, temp.specialization, ',');
		getline(line, temp.phone_number, ',');
		getline(line, years_exp_str, ',');
		getline(line, temp.hospital_branch, ',');
		getline(line, temp.email, ',');
		getline(line, available_str, ',');
		temp.years_experience = stoi(years_exp_str);
        temp.is_available = (available_str) == "1"?  true : false;
        row++;
        doctors[temp.doctor_id] = temp;
    }
    file.close();
}

void Doctor_handler::write_to_file()
{
    ofstream file(filename);
    file << "DoctorID,FirstName,LastName,Specialization,PhoneNumber,YearsExperience,HospitalBranch,Email,Avaliablity" << "\n";
    for (const auto& pair : doctors)
    {
		const Doctor& doc = pair.second;
        int available_flag = doc.is_available ? 1 : 0;
        file << doc.doctor_id << "," << doc.first_name << "," << doc.last_name << "," << doc.specialization << "," << doc.phone_number << "," << doc.years_experience << "," << doc.hospital_branch << "," << doc.email << "," << available_flag << "\n";
    }
    file.close();
}

bool Doctor_handler::check_available(const string& doctor_id) {
    if (doctors.find(doctor_id) != doctors.end()) {
        return doctors[doctor_id].is_available;
    }
    return false;
}

string Doctor_handler::add_doctor(const string& doctor_id, const string& first_name, const string& last_name, const string& specialization, const string& phone_number, int years_experience, const string& hospital_branch, const string& email) {
    if (doctors.find(doctor_id) != doctors.end()) {
        return "Error: Doctor with ID " + doctor_id + " already exists";
    }

    Doctor new_doctor;
    new_doctor.doctor_id = doctor_id;
    new_doctor.first_name = first_name;
    new_doctor.last_name = last_name;
    new_doctor.specialization = specialization;
    new_doctor.phone_number = phone_number;
    new_doctor.years_experience = years_experience;
    new_doctor.hospital_branch = hospital_branch;
    new_doctor.email = email;
    new_doctor.is_available = true;

    doctors[doctor_id] = new_doctor;

    fstream file(filename, ios::app);
	bool available_flag = new_doctor.is_available ? 1 : 0;
	file << doctor_id << "," << first_name << "," << last_name << "," << specialization << "," << phone_number << "," << years_experience << "," << hospital_branch << "," << email << "," << available_flag<< "\n";
    file.close();

    return "Doctor " + first_name + " " + last_name + " added successfully";
}

string Doctor_handler::remove_doctor(const string& doctor_id) {
    if (doctors.find(doctor_id) == doctors.end()) {
        return "Error: Doctor with ID " + doctor_id + " not found";
    }

    string name = doctors[doctor_id].first_name + " " + doctors[doctor_id].last_name;
    doctors.erase(doctor_id);
	write_to_file();
    return "Doctor " + name + " removed successfully";
}

string Doctor_handler::toggle_availability(const string& doctor_id) {
    if (doctors.find(doctor_id) == doctors.end()) {
        return "Error: Doctor with ID " + doctor_id + " not found";
    }

    doctors[doctor_id].is_available = !doctors[doctor_id].is_available;

    string status = doctors[doctor_id].is_available ? "available" : "unavailable";
    return "Doctor " + doctors[doctor_id].first_name + " " + doctors[doctor_id].last_name + " is now " + status;
}

string Doctor_handler::get_doctor_info(const string& doctor_id) {
    if (doctors.find(doctor_id) == doctors.end()) {
        return "Doctor not found";
    }

    Doctor doc = doctors[doctor_id];
    string status = doc.is_available ? "Available" : "Not Available";
    return "Doctor: " + doc.first_name + " " + doc.last_name + " - Status: " + status;
}

string Doctor_handler::get_doctor_by_speciality(const string& specialization) {
    stringstream result;
    bool found = false;

    for (const auto& pair : doctors) {
        const Doctor& doct = pair.second;
        if (doct.specialization == specialization) {
            found = true;
            result << "ID: " << doct.doctor_id << " Name: " << doct.first_name << " " << doct.last_name
                << " Branch: " << doct.hospital_branch << " Available: " << (doct.is_available ? "Yes" : "No") << "\n";
        }
    }

    if (!found) {
        return "No doctors found with specialization: " + specialization;
    }
    return result.str();
}

void Doctor_handler::print_all_doctors() {
    for (const auto& pair : doctors) {
        const Doctor& doc = pair.second;
        cout << "ID: " << doc.doctor_id << ", Name: " << doc.first_name << " " << doc.last_name
            << ", Specialization: " << doc.specialization << ", Available: " << (doc.is_available ? "Yes" : "No") << endl;
    }
}


string Appointment_handler::get_current_datetime() {
    time_t now = time(nullptr);
    tm ltm;
    localtime_s(&ltm, &now);
    stringstream ss;
    ss << (1900 + ltm.tm_year) << "-"
        << (1 + ltm.tm_mon) << "-"
        << ltm.tm_mday << " "
        << ltm.tm_hour << ":"
        << ltm.tm_min << ":"
        << ltm.tm_sec;
    return ss.str();
}

Appointment_handler::Appointment_handler(Doctor_handler* dh) : doc_handler(dh) {}

void Appointment_handler::set_doctor_handler(Doctor_handler* dh) {
    doc_handler = dh;
}

void Appointment_handler::read_from_file()
{
    ifstream file(filename);
    string wholeline;
    int row = 0;
    Appointment temp;
    while (getline(file, wholeline))
    {
        if (row == 0)
        {
            row++;
            continue;
        }
        stringstream line(wholeline);
        getline(line, temp.appointment_id, ',');
        getline(line, temp.patient_id, ',');
        getline(line, temp.doctor_id, ',');
        getline(line, temp.appointment_date, ',');
        getline(line, temp.appointment_time, ',');
        getline(line, temp.reason_for_visit, ',');
        getline(line, temp.status, ',');
        
  
        appointments[temp.appointment_id] = temp;
    }
    file.close();
}

void Appointment_handler::write_to_file()
{
    ofstream file(filename);
    file << "AppointmentID,PatientID,DoctorID,AppointmentDate,AppointmentTime,ReasonForVisit,Status" << "\n";
    for (const auto& pair : appointments)
    {
        const Appointment& appt = pair.second;
        file << appt.appointment_id << "," << appt.patient_id << "," << appt.doctor_id << "," << appt.appointment_date << "," << appt.appointment_time << "," << appt.reason_for_visit << "," << appt.status << "\n";
    }
    file.close();
}

string Appointment_handler::schedule_appointment(const string& appointment_id, const string& patient_id, const string& doctor_id, const string& reason_for_visit) {
    if (appointments.find(appointment_id) != appointments.end()) {
        return "Error: Appointment with ID " + appointment_id + " already exists";
    }
    if (doc_handler != nullptr) {
        if (!doc_handler->check_available(doctor_id)) {
            Doctor doc = doc_handler->getdoctorbyid(doctor_id);
            if (doc.doctor_id.empty()) {
                return "Error: Doctor with ID " + doctor_id + " not found";
            }
            return "Error: Doctor " + doc.first_name + " " + doc.last_name + " is not available";
        }
    }
    string datetime = get_current_datetime();
    Appointment new_appointment;
    new_appointment.appointment_id = appointment_id;
    new_appointment.patient_id = patient_id;
    new_appointment.doctor_id = doctor_id;
    new_appointment.appointment_date = datetime;
    new_appointment.appointment_time = datetime;
    new_appointment.reason_for_visit = reason_for_visit;
    new_appointment.status = "Scheduled";
    appointments[appointment_id] = new_appointment;
	fstream file(filename, ios::app);
	file << appointment_id << "," << patient_id << "," << doctor_id << "," << datetime << "," << datetime << "," << reason_for_visit << "," << "Scheduled" << "\n";
	file.close();
    return "Appointment " + appointment_id + " scheduled successfully for " + datetime;
}

string Appointment_handler::cancel_appointment(const string& appointment_id) {
    if (appointments.find(appointment_id) == appointments.end()) {
        return "Error: Appointment with ID " + appointment_id + " not found";
    }
    if (appointments[appointment_id].status == "Cancelled") {
        return "Appointment " + appointment_id + " is already cancelled";
    }
    appointments[appointment_id].status = "Cancelled";
	write_to_file();
    return "Appointment " + appointment_id + " has been cancelled successfully";
}

string Appointment_handler::get_status(const string& appointment_id) {
    if (appointments.find(appointment_id) == appointments.end()) {
        return "Error: Appointment with ID " + appointment_id + " not found";
    }
    return "Appointment " + appointment_id + " status: " + appointments[appointment_id].status;
}

void Appointment_handler::print_all_appointments() {
    for (const auto& pair : appointments) {
        const Appointment& appt = pair.second;
        cout << "Appointment ID: " << appt.appointment_id << ", Patient ID: " << appt.patient_id
            << ", Doctor ID: " << appt.doctor_id << ", Date: " << appt.appointment_date
            << ", Time: " << appt.appointment_time << ", Status: " << appt.status << endl;
    }
}





void Patient_Handler::load_OPD(string filename)
    {
        ifstream file(filename);
        string line;
        getline(file, line); // skip header
        while (getline(file, line))
        {
            stringstream ss(line);
            string id, name, age, blood, gender, contact, dept;
            getline(ss, id, ','); 
            getline(ss, name, ','); 
            getline(ss, age, ',');
            getline(ss, blood, ','); 
            getline(ss, gender, ','); 
            getline(ss, contact, ','); 
            getline(ss, dept, ',');

            OPD_Patient p;
            p.id = id; 
            p.name = name; 
            p.age = stoi(age);
             p.blood = blood;
            p.gender = gender; 
            p.contact_number = contact;
            p.department = dept;
            opd_patients[id] = p;
            opd_queue.push(p);
        }
        file.close();
    }

    void Patient_Handler::load_Emergency(string filename)
    {
        ifstream file(filename);
        string line;
        getline(file, line); // skip header
        while (getline(file, line))
        {
            stringstream ss(line);
            string id, name, age, blood, gender, relative, sens;
            string vals[10];
            getline(ss, id, ',');
            getline(ss, name, ','); 
            getline(ss, age, ',');
            getline(ss, blood, ','); 
            getline(ss, gender, ','); 
            getline(ss, relative, ','); 
            getline(ss, sens, ',');
            for (int i = 0; i < 10; i++) 
            {
                getline(ss, vals[i], ',');
            }

            Emergency_Patient p;
            p.id = id; p.name = name; p.age = stoi(age); p.blood = blood; p.gender = gender;
            p.relative_number = relative; p.sensitivity = stoi(sens); p.arrivalIndex = emergencyIndex++;
            p.symptoms.bloodPressure = stoi(vals[0]); p.symptoms.heartRate = stoi(vals[1]);
            p.symptoms.oxygenLevel = stoi(vals[2]); p.symptoms.temperature = stoi(vals[3]);
            p.symptoms.respiratoryRate = stoi(vals[4]); p.symptoms.consciousness = stoi(vals[5]);
            p.symptoms.bleeding = stoi(vals[6]); p.symptoms.pain = stoi(vals[7]);
            p.symptoms.chestPain = stoi(vals[8]); p.symptoms.nausea = stoi(vals[9]);

            emergency_patients[id] = p;
            emergency_queue.push(p);
        }
        file.close();
    }

    // ---------- Treat Patients ----------
    void Patient_Handler::treat_OPD()
    {
        if (!opd_queue.empty())
        {
            OPD_Patient p = opd_queue.front();
            opd_queue.pop();
            cout << "OPD patient treated: " << p.name << " | Department: " << p.department << endl;
        }
        else 
        {
            cout << "No OPD patients.\n";
        }
    }

    void Patient_Handler::treat_Emergency()
    {
        if (!emergency_queue.empty())
        {
            Emergency_Patient p = emergency_queue.top();
            emergency_queue.pop();
            cout << "Emergency patient treated: " << p.name << " | Sensitivity: " << p.sensitivity << endl;
        }
        else 
        {
            cout << "No Emergency patients.\n";
        }
    }

    // ---------- Add Patients ----------
    void Patient_Handler::add_OPD_patient(const OPD_Patient& p)
    {
        opd_patients[p.id] = p;
        opd_queue.push(p);
        write_OPD_file("OPD.csv", opd_patients);
        cout << "OPD patient added: " << p.name << endl;
    }

    void Patient_Handler::add_Emergency_patient(Emergency_Patient p)
    {
        p.arrivalIndex = emergencyIndex++;
        emergency_patients[p.id] = p;
        emergency_queue.push(p);
        write_Emergency_file("Emergency.csv", emergency_patients);
        cout << "Emergency patient added: " << p.name << endl;
    }

    // ---------- Write CSVs ----------
    void Patient_Handler::write_OPD_file(const string& filename, map<string, OPD_Patient>& patients)
    {
        ofstream file(filename);
        file << "patient_id,name,age,blood,gender,contact_number,department\n";
        for (auto& i : patients)
        {
            OPD_Patient& p = i.second;
            file << p.id << "," << p.name << "," << p.age << "," << p.blood << "," << p.gender << "," << p.contact_number << "," << p.department << "\n";
        }
        file.close();
    }

    void Patient_Handler::write_Emergency_file(const string& filename, map<string, Emergency_Patient>& patients)
    {
        ofstream file(filename);
        file << "patient_id,name,age,blood,gender,relative_number,sensitivity,bloodPressure,heartRate,oxygenLevel,temperature,respiratoryRate,consciousness,bleeding,pain,chestPain,nausea\n";
        for (auto& i : patients)
        {
            Emergency_Patient& p = i.second;
            file << p.id << "," << p.name << "," << p.age << "," 
                 << p.blood << "," << p.gender << "," << p.relative_number << "," 
                 << p.sensitivity << ","
                 << p.symptoms.bloodPressure << "," << p.symptoms.heartRate << ","
                 << p.symptoms.oxygenLevel << "," << p.symptoms.temperature << ","
                 << p.symptoms.respiratoryRate << "," << p.symptoms.consciousness << ","
                 << p.symptoms.bleeding << "," << p.symptoms.pain << ","
                 << p.symptoms.chestPain << "," << p.symptoms.nausea << "\n";
        }
        file.close();
    }

     


 