#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include "Doctor_Handler.h"
#include "Appoinment_Handler.h"
#include "Patient_Handler.h"
#include "Recomendation_System.h"
#include "Billing_Handler.h"


namespace py = pybind11;

PYBIND11_MODULE(hospital_backend, m) {
    // Doctor & Appointment bindings (keep existing ones)...
    py::class_<Doctor_handler>(m, "DoctorHandler")
        .def(py::init<>())
        .def("read_from_file", &Doctor_handler::read_from_file)
        .def("add_doctor", &Doctor_handler::add_doctor)
        .def("get_doctor_info", &Doctor_handler::get_doctor_info)
        .def("toggle_availability", &Doctor_handler::toggle_availability)
        .def("get_all_doctors_vec", &Doctor_handler::get_all_doctors_vec);

    py::class_<Doctor>(m, "Doctor")
        .def(py::init<>())
        .def_readwrite("doctor_id", &Doctor::doctor_id)
        .def_readwrite("first_name", &Doctor::first_name)
        .def_readwrite("last_name", &Doctor::last_name)
        .def_readwrite("specialization", &Doctor::specialization)
        .def_readwrite("hospital_branch", &Doctor::hospital_branch)
        .def_readwrite("is_available", &Doctor::is_available);

    py::class_<Appointment>(m, "Appointment")
        .def(py::init<>())
        .def_readwrite("appointment_id", &Appointment::appointment_id)
        .def_readwrite("patient_id", &Appointment::patient_id)
        .def_readwrite("doctor_id", &Appointment::doctor_id)
        .def_readwrite("reason_for_visit", &Appointment::reason_for_visit)
        .def_readwrite("status", &Appointment::status);

    // --- NEW: Patient Bindings ---
    py::class_<OPD_Patient>(m, "OPDPatient")
        .def(py::init<>())
        .def_readwrite("id", &OPD_Patient::id)
        .def_readwrite("name", &OPD_Patient::name)
        .def_readwrite("age", &OPD_Patient::age)
        .def_readwrite("department", &OPD_Patient::department);

    py::class_<Emergency_Patient>(m, "EmergencyPatient")
        .def(py::init<>())
        .def_readwrite("id", &Emergency_Patient::id)
        .def_readwrite("name", &Emergency_Patient::name)
        .def_readwrite("sensitivity", &Emergency_Patient::sensitivity);

    py::class_<Patient_Handler>(m, "PatientHandler")
        .def(py::init<>())
        .def("load_OPD", &Patient_Handler::load_OPD)
        .def("load_Emergency", &Patient_Handler::load_Emergency)
        .def("add_OPD_patient", &Patient_Handler::add_OPD_patient)
        .def("add_Emergency_patient", &Patient_Handler::add_Emergency_patient)
        .def("treat_OPD", &Patient_Handler::treat_OPD)
        .def("treat_Emergency", &Patient_Handler::treat_Emergency);

    // --- NEW: Recommendation System Bindings ---
    py::class_<Recom_System>(m, "RecomSystem")
        .def(py::init<>())
        .def("load_data", &Recom_System::load_data)
        .def("get_condition", &Recom_System::get_condition)
        .def("get_precautions", &Recom_System::get_precautions)
        .def("get_medicines", &Recom_System::get_medicines);

    py::class_<Appointment_handler>(m, "AppointmentHandler")
        .def(py::init<Doctor_handler*>())
        .def("set_doctor_handler", &Appointment_handler::set_doctor_handler)
        .def("schedule_appointment", &Appointment_handler::schedule_appointment)
        .def("cancel_appointment", &Appointment_handler::cancel_appointment)
        .def("get_status", &Appointment_handler::get_status)
        .def("print_all_appointments", &Appointment_handler::print_all_appointments)
        .def("read_from_file", &Appointment_handler::read_from_file)
        .def("write_to_file", &Appointment_handler::write_to_file)
        .def("get_all_appointments_vec", &Appointment_handler::get_all_appointments_vec);

    // --- NEW: Billing Handler Bindings ---
    py::class_<Billing_Handler>(m, "BillingHandler")
        .def(py::init<>())
        .def("load_medicine_prices", &Billing_Handler::load_medicine_prices)
        .def("load_specialization_fees", &Billing_Handler::load_specialization_fees)
        .def("create_opd_bill", &Billing_Handler::create_opd_bill)
        .def("create_emergency_bill", &Billing_Handler::create_emergency_bill)
        .def("add_medicine_to_bill", &Billing_Handler::add_medicine_to_bill)
        .def("add_custom_charge", &Billing_Handler::add_custom_charge)
        .def("mark_as_paid", &Billing_Handler::mark_as_paid)
        .def("print_bill", &Billing_Handler::print_bill)
        .def("save_bills_to_file", &Billing_Handler::save_bills_to_file);
}