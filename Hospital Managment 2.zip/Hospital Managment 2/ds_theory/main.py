import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import hospital_backend # Your pybind11 compiled module

# --- MODERN STYLING ---
QSS_STYLE = """
QMainWindow { background-color: #f0f2f5; }
#SideBar { background-color: #1e293b; min-width: 240px; }
#SideBar QPushButton { 
    color: #cbd5e1; border: none; padding: 15px; text-align: left; 
    font-size: 14px; border-radius: 5px; margin: 5px 10px;
}
#SideBar QPushButton:hover { background-color: #334155; color: white; }
#SideBar QPushButton:checked { background-color: #3b82f6; color: white; font-weight: bold; }
#ContentArea { background-color: white; border-top-left-radius: 20px; }
QTableWidget { border: none; gridline-color: #e2e8f0; }
QHeaderView::section { background-color: #f8fafc; padding: 10px; border: none; font-weight: bold; }
#ActionBtn { background-color: #3b82f6; color: white; padding: 8px 15px; border-radius: 5px; }
"""

class HospitalManagementSystem(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("HMS Pro v2.0 - Enterprise Healthcare Suite")
        self.resize(1280, 850)
        
        # Initialize C++ Backends via pybind11
        self.patient_h = hospital_backend.PatientHandler()
        self.doctor_h = hospital_backend.DoctorHandler()
        self.appoint_h = hospital_backend.AppointmentHandler(self.doctor_h)
        self.billing_h = hospital_backend.BillingHandler()
        self.recom_s = hospital_backend.RecomSystem()

        # Load existing data
        self.doctor_h.read_from_file()
        self.appoint_h.read_from_file()
        self.billing_h.load_medicine_prices()
        
        self.init_ui()
        self.setStyleSheet(QSS_STYLE)

    def init_ui(self):
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QHBoxLayout(main_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # --- Sidebar ---
        self.sidebar = QFrame()
        self.sidebar.setObjectName("SideBar")
        side_layout = QVBoxLayout(self.sidebar)
        
        logo = QLabel("HOSPITAL OS")
        logo.setStyleSheet("color: #3b82f6; font-size: 22px; font-weight: 800; padding: 20px;")
        side_layout.addWidget(logo)

        self.nav_group = QButtonGroup(self)
        menu_items = [
            ("Dashboard", 0), ("Doctor Registry", 1), 
            ("Patient Queue", 2), ("Appointments", 3), 
            ("Billing & Finance", 4), ("AI Diagnosis", 5)
        ]

        for text, idx in menu_items:
            btn = QPushButton(text)
            btn.setCheckable(True)
            if idx == 0: btn.setChecked(True)
            btn.clicked.connect(lambda _, i=idx: self.stack.setCurrentIndex(i))
            self.nav_group.addButton(btn)
            side_layout.addWidget(btn)
        
        side_layout.addStretch()
        layout.addWidget(self.sidebar)

        # --- Main Content ---
        self.stack = QStackedWidget()
        self.stack.setObjectName("ContentArea")
        layout.addWidget(self.stack)

        # Initialize Pages
        self.stack.addWidget(self.create_dashboard())
        self.stack.addWidget(self.create_doctor_page())
        self.stack.addWidget(self.create_patient_page())
        self.stack.addWidget(self.create_appointment_page())
        self.stack.addWidget(self.create_billing_page())
        self.stack.addWidget(self.create_ai_page())

    # --- DOCTOR MANAGEMENT ---
    def create_doctor_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        
        header = QHBoxLayout()
        header.addWidget(QLabel("Staff Directory", font=QFont("Arial", 20, QFont.Bold)))
        add_btn = QPushButton("+ Add Doctor")
        add_btn.setObjectName("ActionBtn")
        add_btn.clicked.connect(self.add_doctor_dialog)
        header.addWidget(add_btn)
        layout.addLayout(header)

        self.doc_table = QTableWidget(0, 5)
        self.doc_table.setHorizontalHeaderLabels(["ID", "Name", "Specialization", "Branch", "Status"])
        self.doc_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.doc_table)
        self.refresh_doctors()
        return page

    def refresh_doctors(self):
        doctors = self.doctor_h.get_all_doctors_vec() # C++
        self.doc_table.setRowCount(0)
        for d in doctors:
            row = self.doc_table.rowCount()
            self.doc_table.insertRow(row)
            self.doc_table.setItem(row, 0, QTableWidgetItem(d.doctor_id))
            self.doc_table.setItem(row, 1, QTableWidgetItem(f"{d.first_name} {d.last_name}"))
            self.doc_table.setItem(row, 2, QTableWidgetItem(d.specialization))
            self.doc_table.setItem(row, 3, QTableWidgetItem(d.hospital_branch))
            status = "Available" if d.is_available else "On Leave"
            self.doc_table.setItem(row, 4, QTableWidgetItem(status))

    # --- APPOINTMENT SYSTEM ---
    def create_appointment_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(QLabel("Appointment Scheduler", font=QFont("Arial", 20, QFont.Bold)))
        
        self.app_table = QTableWidget(0, 5)
        self.app_table.setHorizontalHeaderLabels(["ID", "Patient", "Doctor", "Reason", "Status"])
        self.app_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.app_table)
        
        btn_layout = QHBoxLayout()
        sched_btn = QPushButton("Schedule New")
        sched_btn.setObjectName("ActionBtn")
        sched_btn.clicked.connect(self.schedule_dialog)
        btn_layout.addWidget(sched_btn)
        layout.addLayout(btn_layout)
        
        self.refresh_appointments()
        return page

    # --- BILLING SYSTEM ---
    def create_billing_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(QLabel("Financial Records", font=QFont("Arial", 20, QFont.Bold)))

        # Split view: Bill list and Medicine adder
        content = QHBoxLayout()
        
        self.bill_table = QTableWidget(0, 4)
        self.bill_table.setHorizontalHeaderLabels(["Patient ID", "Type", "Total", "Status"])
        content.addWidget(self.bill_table, 2)
        
        # Medicine Panel
        med_panel = QGroupBox("Add Charges")
        med_layout = QFormLayout(med_panel)
        self.p_id_input = QLineEdit()
        self.med_name = QLineEdit()
        self.qty = QSpinBox()
        med_layout.addRow("Patient ID:", self.p_id_input)
        med_layout.addRow("Service/Med:", self.med_name)
        med_layout.addRow("Quantity:", self.qty)
        add_med_btn = QPushButton("Add to Bill")
        add_med_btn.clicked.connect(self.add_charge)
        med_layout.addRow(add_med_btn)
        content.addWidget(med_panel, 1)
        
        layout.addLayout(content)
        return page

    def add_charge(self):
        pid = self.p_id_input.text()
        item = self.med_name.text()
        q = self.qty.value()
        # Call C++ Billing Logic
        success = self.billing_h.add_medicine_to_bill(pid, item, q)
        if success:
            QMessageBox.information(self, "Success", f"Added {item} to invoice.")
            self.billing_h.print_bill(pid) # Print to C++ console
        else:
            QMessageBox.warning(self, "Error", "Bill not found or invalid medicine.")

    # --- AI RECOMMENDATION ---
    def create_ai_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(QLabel("Clinical Diagnosis Support", font=QFont("Arial", 20, QFont.Bold)))
        
        self.symptom_in = QTextEdit()
        self.symptom_in.setPlaceholderText("Enter symptoms (e.g., headache, muscle_pain, skin_rash)...")
        layout.addWidget(self.symptom_in)
        
        run_btn = QPushButton("Run AI Recommendation")
        run_btn.clicked.connect(self.run_ai)
        layout.addWidget(run_btn)
        
        self.ai_result = QTextBrowser()
        layout.addWidget(self.ai_result)
        return page

    def run_ai(self):
        symptoms = self.symptom_in.toPlainText().replace('\n', ',').split(',')
        symptoms = [s.strip() for s in symptoms if s.strip()]
        
        # C++ Graph Logic
        disease = self.recom_s.get_condition(symptoms)
        precautions = self.recom_s.get_precautions(disease)
        meds = self.recom_s.get_medicines(disease)
        
        res_text = f"<h2>Diagnosis: {disease.replace('_', ' ').upper()}</h2>"
        res_text += "<b>Recommended Precautions:</b><ul>"
        for p in precautions: res_text += f"<li>{p}</li>"
        res_text += "</ul><b>Suggested Medicines:</b><ul>"
        for m in meds: res_text += f"<li>{m}</li>"
        res_text += "</ul>"
        self.ai_result.setHtml(res_text)

    # --- CORE REFRESH LOGIC ---
    def refresh_appointments(self):
        apps = self.appoint_h.get_all_appointments_vec()
        self.app_table.setRowCount(0)
        for a in apps:
            row = self.app_table.rowCount()
            self.app_table.insertRow(row)
            self.app_table.setItem(row, 0, QTableWidgetItem(a.appointment_id))
            self.app_table.setItem(row, 1, QTableWidgetItem(a.patient_id))
            self.app_table.setItem(row, 2, QTableWidgetItem(a.doctor_id))
            self.app_table.setItem(row, 3, QTableWidgetItem(a.reason_for_visit))
            self.app_table.setItem(row, 4, QTableWidgetItem(a.status))

    def create_dashboard(self):
        p = QWidget(); l = QVBoxLayout(p)
        l.addWidget(QLabel("Welcome to HMS Dashboard", font=QFont("Arial", 24)))
        return p

    def create_patient_page(self):
        p = QWidget(); l = QVBoxLayout(p)
        l.addWidget(QLabel("Patient Queueing", font=QFont("Arial", 20)))
        return p

    def add_doctor_dialog(self): pass
    def schedule_dialog(self): pass

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setFont(QFont("Segoe UI", 10))
    window = HospitalManagementSystem()
    window.show()
    sys.exit(app.exec_())