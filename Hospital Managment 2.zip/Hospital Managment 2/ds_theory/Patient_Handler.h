#pragma once

#include<iostream>
#include<string>
#include<map>
#include<sstream>
#include<vector>
#include<fstream>
#include<ctime>
#include<queue>
#include<functional>

using namespace std;

struct Patient_Symptoms
{
    int bloodPressure;
    int heartRate;
    int oxygenLevel;
    int temperature;
    int respiratoryRate;
    int consciousness;
    int bleeding;
    int pain;
    int chestPain;
    int nausea;

    Patient_Symptoms()
    {
        bloodPressure = heartRate = oxygenLevel = temperature = respiratoryRate =
        consciousness = bleeding = pain = chestPain = nausea = -1;
    }
};

struct Patient
{
    string name;
    int age;
    string blood;
    string gender;
    string contact_number;
    string department;
    string id;

    Patient()
    {
        name = blood = gender = contact_number = department = id = "";
        age = -1;
    }
};

struct OPD_Patient : public Patient {};
struct Emergency_Patient : public Patient
{
    string relative_number;
    int sensitivity;
    Patient_Symptoms symptoms;
    int arrivalIndex; 

    Emergency_Patient() 
    { 
        sensitivity = -1; relative_number = ""; arrivalIndex = -1; 
    }
};

struct compare_sensitivity
{
    bool operator()(Emergency_Patient const& p1, Emergency_Patient const& p2)
    {
        if (p1.sensitivity == p2.sensitivity)
        {
            return p1.arrivalIndex > p2.arrivalIndex; 
        }
        else
        {
            return p1.sensitivity < p2.sensitivity; 
        } 
    }
};


class Patient_Handler
{
private:
    queue<OPD_Patient> opd_queue;
    map<string, OPD_Patient> opd_patients;
    priority_queue<Emergency_Patient, vector<Emergency_Patient>, compare_sensitivity> emergency_queue;
    map<string, Emergency_Patient> emergency_patients;
    int emergencyIndex = 0; 
public:
    void load_OPD(string filename);
    void load_Emergency(string filename);
    void add_OPD_patient(const OPD_Patient& p);
    void add_Emergency_patient(Emergency_Patient p);
    void write_OPD_file(const string& filename, map<string, OPD_Patient>& patients);
    void write_Emergency_file(const string& filename, map<string, Emergency_Patient>& patients);
    void treat_OPD();
    void treat_Emergency();
    OPD_Patient accessOPDByID(string p_id);
    Emergency_Patient accessEmByID(string p_id);


    
};