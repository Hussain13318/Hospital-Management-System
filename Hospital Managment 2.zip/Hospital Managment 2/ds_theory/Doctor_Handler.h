#pragma once
#include <iostream>
#include <string>
#include <map>
#include <sstream>
#include <vector>
#include <fstream>

using namespace std;



struct Doctor {
    string doctor_id;
    string first_name;
    string last_name;
    string specialization;
    string phone_number;
    int years_experience;
    string hospital_branch;
    string email;
    bool is_available;

    Doctor() : years_experience(0), is_available(true) {}
};

class Doctor_handler {
private:
    map<string, Doctor> doctors;
	string filename = "archive/doctors.csv";

public:
    Doctor getdoctorbyid(const string& doctor_id);
    void read_from_file();
    void write_to_file();
    bool check_available(const string& doctor_id);
    string add_doctor(const string& doctor_id, const string& first_name, const string& last_name, const string& specialization, const string& phone_number, int years_experience, const string& hospital_branch, const string& email);
    string remove_doctor(const string& doctor_id);
    string toggle_availability(const string& doctor_id);
    string get_doctor_by_speciality(const string& specialization);
    string get_doctor_info(const string& doctor_id);
    void print_all_doctors();

    std::vector<Doctor> get_all_doctors_vec() {
    std::vector<Doctor> d_list;
    for(auto const& [id, doc] : doctors) d_list.push_back(doc);
    return d_list;
}

// In Appointment_handler class

};