#include "Billing_Handler.h"

// Helper to prevent 'std::invalid_argument' crashes from CSV headers or empty lines
int Billing_Handler::safe_stoi(const string& str) {
    if (str.empty()) return 0;
    try {
        // Remove potential whitespace
        size_t first = str.find_first_not_of(" \t\n\r");
        if (first == string::npos) return 0;
        size_t last = str.find_last_not_of(" \t\n\r");
        return stoi(str.substr(first, (last - first + 1)));
    } catch (...) {
        return 0; 
    }
}

string Billing_Handler::get_current_time() {
    time_t now = time(0);
    tm ltm;
    localtime_s(&ltm, &now);
    char buffer[20];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M", &ltm);
    return string(buffer);
}

void Billing_Handler::recompute_total(Bill& b) {
    b.total_amount = 0;
    for (const auto& item : b.items) {
        b.total_amount += item.amount;
    }
}

// Fixed: Added safe_stoi to prevent medicine_file crashes
void Billing_Handler::load_medicine_prices() {
    ifstream file(medicine_file);
    if (!file.is_open()) return;
    string line, name, price;
    getline(file, line); // Skip header
    while (getline(file, line)) {
        if (line.empty()) continue;
        stringstream ss(line);
        getline(ss, name, ',');
        getline(ss, price, ',');
        if(!name.empty())
            medicine_prices[name] = safe_stoi(price);
    }
    file.close();
}

// Fixed: Now automatically looks up fee if spec_fee is passed as -1
void Billing_Handler::create_opd_bill(const OPD_Patient& p, int spec_fee) {
    Bill b;
    b.patient_id = p.id;
    b.patient_name = p.name;
    b.bill_type = "OPD";
    b.created_at = get_current_time();
    
    int final_fee = spec_fee;
    if (final_fee <= 0 && specialization_fees.count(p.department)) {
        final_fee = specialization_fees[p.department];
    } else if (final_fee <= 0) {
        final_fee = 500; // Default fallback
    }

    b.items.push_back(BillItem("Consultation Fee (" + p.department + ")", final_fee));
    recompute_total(b);
    active_bills[p.id] = b;
}

void Billing_Handler::create_emergency_bill(const Emergency_Patient& p, int base_fee) {
    Bill b;
    b.patient_id = p.id;
    b.patient_name = p.name;
    b.bill_type = "Emergency";
    b.created_at = get_current_time();
    
    int severity_charge = p.sensitivity * 100; 
    b.items.push_back(BillItem("Emergency Base Fee", base_fee));
    b.items.push_back(BillItem("Severity Surcharge", severity_charge));
    
    recompute_total(b);
    active_bills[p.id] = b;
}

bool Billing_Handler::add_medicine_to_bill(string patient_id, string med_name, int qty) {
    if (active_bills.find(patient_id) == active_bills.end()) return false;
    if (medicine_prices.find(med_name) == medicine_prices.end()) return false;

    int total_med_cost = medicine_prices[med_name] * qty;
    active_bills[patient_id].items.push_back(BillItem("Med: " + med_name + " x" + to_string(qty), total_med_cost));
    recompute_total(active_bills[patient_id]);
    return true;
}

// Merged and Cleaned up Print Function
void Billing_Handler::print_bill(string patient_id) {
    if (active_bills.find(patient_id) == active_bills.end()) {
        cout << "Bill not found for ID: " << patient_id << endl;
        return;
    }
    Bill& b = active_bills[patient_id];
    cout << "\n======= HOSPITAL BILL =======" << endl;
    cout << "Patient ID: " << b.patient_id << " | Name: " << b.patient_name << endl;
    cout << "Date: " << b.created_at << " | Type: " << b.bill_type << " | Status: " << b.status << endl;
    cout << "-----------------------------" << endl;
    for (const auto& item : b.items) {
        cout << "- " << item.title << " : Rs. " << item.amount << endl;
    }
    cout << "-----------------------------" << endl;
    cout << "TOTAL AMOUNT: Rs. " << b.total_amount << endl;
    cout << "=============================\n" << endl;
}

bool Billing_Handler::add_custom_charge(string patient_id, string service_name, int cost) {
    if (active_bills.find(patient_id) == active_bills.end()) return false;
    active_bills[patient_id].items.push_back(BillItem(service_name, cost));
    recompute_total(active_bills[patient_id]);
    return true;
}

void Billing_Handler::mark_as_paid(string patient_id) {
    if (active_bills.find(patient_id) != active_bills.end()) {
        active_bills[patient_id].status = "PAID";
    }
}

// Fixed: Added safe_stoi for total column
void Billing_Handler::load_bills_from_file() {
    ifstream file(billing_file);
    if (!file.is_open()) return;

    string line;
    getline(file, line); // Skip header
    while (getline(file, line)) {
        if (line.empty() || line.find_first_not_of(" \t\n\r") == string::npos) continue;
        stringstream ss(line);
        string id, name, type, status, total;
        getline(ss, id, ',');
        getline(ss, name, ',');
        getline(ss, type, ',');
        getline(ss, status, ',');
        getline(ss, total, ',');

        Bill b;
        b.patient_id = id;
        b.patient_name = name;
        b.bill_type = type;
        b.status = status;
        b.total_amount = safe_stoi(total);
        active_bills[id] = b;
    }
    file.close();
}

void Billing_Handler::save_bills_to_file() {
    ofstream file(billing_file,ios::app);
    file << "PatientID,Name,Type,Status,Total,Date Created\n";
    for (auto const& [id, b] : active_bills) {
        file << b.patient_id << "," << b.patient_name << "," << b.bill_type << "," << b.status << "," << b.total_amount <<  "," <<b.created_at<<"\n";
    }
    file.close();
}

void Billing_Handler::load_specialization_fees(string filename) {
    ifstream file(filename);
    if (!file.is_open()) return;
    string line;
    getline(file, line); // Skip header

    while (getline(file, line)) {
        if (line.empty()) continue;
        stringstream ss(line);
        string spec, feeStr;
        getline(ss, spec, ',');
        getline(ss, feeStr, ',');

        if (!spec.empty()) {
            specialization_fees[spec] = safe_stoi(feeStr);
        }
    }
    file.close();
}