// ===================== BILLING (OPD + EMERGENCY) =====================


#include <string>
#include <map>
#include <vector>
#include <fstream>
#include <sstream>
#include <ctime>
#include <algorithm>
#include <cctype>

using namespace std;

struct bill_item
{
    string title;
    int amount;

    bill_item() : title(""), amount(0) {}
    bill_item(const string& t, int a) : title(t), amount(a) {}
};

struct bill
{
    int patient_id;           // patient.id
    string patient_name;      // patient.name
    string bill_type;         // "OPD" / "Emergency"
    string department;        // OPD
    int sensitivity;          // Emergency
    string created_at;
    string paid_at;

    vector<bill_item> items;

    int subtotal;
    int total;

    // Simple state only:
    // "OPEN" -> you can add medicines/tests
    // "PAID" -> closed
    // "VOID" -> cancelled
    string status;

    bill()
    {
        patient_id = -1;
        patient_name = "";
        bill_type = "";
        department = "";
        sensitivity = 0;
        created_at = "";
        paid_at = "";
        subtotal = total = 0;
        status = "OPEN";
    }
};

class Billing_Handler
{
private:
    map<int, bill> bills_by_patient;            // patient_id -> bill

    // We store normalized keys to avoid mismatch due to spaces/case.
    map<string, int> medicine_price;            // normalized med -> price
    map<string, int> specialization_fee;        // normalized specialization/department -> fee

    int emergency_base_fee;
    int emergency_per_point;

    
    
    string safe_now_datetime()
    {
        time_t now = time(nullptr);

        tm ltm{};
        localtime_s(&ltm, &now);


        stringstream ss;
        ss << (1900 + ltm.tm_year) << "-"
           << (1 + ltm.tm_mon) << "-"
           << ltm.tm_mday << " "
           << ltm.tm_hour << ":"
           << ltm.tm_min << ":"
           << ltm.tm_sec;

        return ss.str();
    }

    int calc_subtotal(const bill& b) const
    {
        int s = 0;
        for (const auto& it : b.items) s += it.amount;
        return s;
    }

    void recompute(bill& b)
    {
        b.subtotal = calc_subtotal(b);
        b.total = b.subtotal;
    }

    string items_to_string(const vector<bill_item>& items)
    {
        // title:amount|title:amount|...
        // CSV safe: replace ',' and '|' inside title
        stringstream ss;
        for (int i = 0; i < (int)items.size(); i++)
        {
            string t = items[i].title;
            for (char& c : t)
                if (c == ',' || c == '|') c = ' ';

            ss << t << ":" << items[i].amount;
            if (i != (int)items.size() - 1) ss << "|";
        }
        return ss.str();
    }

    vector<bill_item> string_to_items(const string& s)
    {
        vector<bill_item> out;
        stringstream ss(s);
        string token;

        while (getline(ss, token, '|'))
        {
            size_t pos = token.rfind(':');
            if (pos == string::npos) continue;

            string title = token.substr(0, pos);
            int amount = stoi(token.substr(pos + 1), 0);
            out.push_back(bill_item(title, amount));
        }
        return out;
    }

public:
    Billing_Handler()
    {
        emergency_base_fee = 2000;
        emergency_per_point = 50;

        // Defaults (tum chaaho to CSV se overwrite kar lena)
        specialization_fee[normalize_key("General Physician")] = 700;
        specialization_fee[normalize_key("Neurology")] = 1500;
        specialization_fee[normalize_key("Orthopedics")] = 1200;
        specialization_fee[normalize_key("Psychiatry")] = 1100;
        specialization_fee[normalize_key("ENT")] = 900;
        specialization_fee[normalize_key("Denatistry")] = 1000; // same spelling as your OPD code
    }

    void set_emergency_base_fee(int fee) { if (fee >= 0) emergency_base_fee = fee; }
    void set_emergency_per_point(int fee) { if (fee >= 0) emergency_per_point = fee; }

    // ---------------- CSV LOADERS ----------------
    // medicines CSV format: MedicineName,Price
    bool load_medicine_prices(const string& filename)
    {
        ifstream file(filename);
        if (!file.is_open()) return false;

        string line;
        int row = 0;

        while (getline(file, line))
        {
            line = trim_copy(line);
            if (line.empty()) continue;

            if (row == 0) { row++; continue; } // header

            stringstream ss(line);
            string name, priceStr;
            getline(ss, name, ',');
            getline(ss, priceStr, ',');

            name = trim_copy(name);
            priceStr = trim_copy(priceStr);

            if (name.empty()) continue;

            int price = to_int(priceStr, -1);
            if (price < 0) continue;

            medicine_price[normalize_key(name)] = price;
            row++;
        }

        file.close();
        return true;
    }

    // specialization fees CSV format: Specialization,Fee
    bool load_specialization_fees(const string& filename)
    {
        ifstream file(filename);
        if (!file.is_open()) return false;

        string line;
        int row = 0;

        while (getline(file, line))
        {
            line = trim_copy(line);
            if (line.empty()) continue;

            if (row == 0) { row++; continue; } // header

            stringstream ss(line);
            string spec, feeStr;
            getline(ss, spec, ',');
            getline(ss, feeStr, ',');

            spec = trim_copy(spec);
            feeStr = trim_copy(feeStr);

            if (spec.empty()) continue;

            int fee = to_int(feeStr, -1);
            if (fee < 0) continue;

            specialization_fee[normalize_key(spec)] = fee;
            row++;
        }

        file.close();
        return true;
    }

    // ---------------- CREATE BILLS ----------------
    // OPD: doctor/specialization/department fee add hogi (CSV se / defaults se)
    bool create_opd_bill(const patient& rp)
    {
        if (rp.id <= 0) return false;
        if (bills_by_patient.find(rp.id) != bills_by_patient.end()) return false;

        bill b;
        b.patient_id = rp.id;
        b.patient_name = rp.name;
        b.bill_type = "OPD";
        b.department = rp.department;
        b.sensitivity = 0;
        b.created_at = safe_now_datetime();
        b.paid_at = "";
        b.status = "OPEN";

        int docFee = 0;
        auto it = specialization_fee.find(normalize_key(rp.department));
        if (it != specialization_fee.end()) docFee = it->second;

        b.items.push_back(bill_item("Doctor Fee (" + rp.department + ")", docFee));

        recompute(b);
        bills_by_patient[rp.id] = b;
        return true;
    }

    // Emergency: base + severity charges (simple)
    bool create_emergency_bill(const patient& ep)
    {
        if (ep.id <= 0) return false;
        if (bills_by_patient.find(ep.id) != bills_by_patient.end()) return false;

        bill b;
        b.patient_id = ep.id;
        b.patient_name = ep.name;
        b.bill_type = "Emergency";
        b.department = "";
        b.sensitivity = ep.sensitivity;
        b.created_at = safe_now_datetime();
        b.paid_at = "";
        b.status = "OPEN";

        b.items.push_back(bill_item("Emergency Base Fee", emergency_base_fee));
        b.items.push_back(bill_item("Severity Charges", ep.sensitivity * emergency_per_point));

        recompute(b);
        bills_by_patient[ep.id] = b;
        return true;
    }

    // ---------------- ADD MEDICINES / CHARGES ----------------
    // OPD me doctor ke likhay huay meds -> CSV se price le kar add
    // (Emergency me bhi add karna chaho to use kar sakte ho)
    bool add_medicine(int patient_id, const string& med_name, int qty = 1)
    {
        auto itb = bills_by_patient.find(patient_id);
        if (itb == bills_by_patient.end()) return false;
        if (itb->second.status != "OPEN") return false;
        if (qty <= 0) qty = 1;

        string key = normalize_key(med_name);
        auto itp = medicine_price.find(key);
        if (itp == medicine_price.end()) return false;

        int price = itp->second * qty;
        itb->second.items.push_back(bill_item("Medicine: " + trim_copy(med_name) + " x" + to_string(qty), price));
        recompute(itb->second);
        return true;
    }

    // tests / extra charges (OPD or Emergency)
    bool add_charge(int patient_id, const string& title, int amount)
    {
        auto itb = bills_by_patient.find(patient_id);
        if (itb == bills_by_patient.end()) return false;
        if (itb->second.status != "OPEN") return false;
        if (amount <= 0) return false;

        itb->second.items.push_back(bill_item(title, amount));
        recompute(itb->second);
        return true;
    }

    // ---------------- FULL PAYMENT / CLOSE ----------------
    // "unpaid/partial" wali complexity nahi: bas full pay -> PAID
    bool pay_full_and_close(int patient_id)
    {
        auto itb = bills_by_patient.find(patient_id);
        if (itb == bills_by_patient.end()) return false;
        if (itb->second.status != "OPEN") return false;

        recompute(itb->second);              // ensure total updated
        itb->second.status = "PAID";
        itb->second.paid_at = safe_now_datetime();
        return true;
    }

    bool void_bill(int patient_id)
    {
        auto itb = bills_by_patient.find(patient_id);
        if (itb == bills_by_patient.end()) return false;
        itb->second.status = "VOID";
        return true;
    }

    // ---------------- READ ----------------
    bool bill_exists(int patient_id) const
    {
        return bills_by_patient.find(patient_id) != bills_by_patient.end();
    }

    string get_bill_summary(int patient_id)
    {
        auto itb = bills_by_patient.find(patient_id);
        if (itb == bills_by_patient.end()) return "Error: Bill not found";

        bill& b = itb->second;
        recompute(b);

        stringstream ss;
        ss << "Patient-ID: " << b.patient_id << "\n";
        ss << "Name: " << b.patient_name << "\n";
        ss << "Type: " << b.bill_type << "\n";
        if (!b.department.empty()) ss << "Department: " << b.department << "\n";
        if (b.bill_type == "Emergency") ss << "Sensitivity: " << b.sensitivity << "\n";
        ss << "Created: " << b.created_at << "\n";
        ss << "State: " << b.status << "\n";
        if (b.status == "PAID") ss << "Paid At: " << b.paid_at << "\n";

        ss << "Items:\n";
        for (auto& x : b.items)
            ss << " - " << x.title << ": " << x.amount << "\n";

        ss << "Subtotal: " << b.subtotal << "\n";
        ss << "Total: " << b.total << "\n";

        return ss.str();
    }

    // ---------------- SAVE / LOAD ----------------
    void write_to_file(const string& filename)
    {
        ofstream file(filename);
        file << "patient_id,patient_name,bill_type,department,sensitivity,created_at,paid_at,status,subtotal,total,items\n";

        for (auto& pair : bills_by_patient)
        {
            bill& b = pair.second;
            recompute(b);

            string pname = b.patient_name;
            for (char& c : pname) if (c == ',') c = ' '; // CSV safe

            string dept = b.department;
            for (char& c : dept) if (c == ',') c = ' ';

            file << b.patient_id << ","
                 << pname << ","
                 << b.bill_type << ","
                 << dept << ","
                 << b.sensitivity << ","
                 << b.created_at << ","
                 << b.paid_at << ","
                 << b.status << ","
                 << b.subtotal << ","
                 << b.total << ","
                 << items_to_string(b.items)
                 << "\n";
        }
        file.close();
    }

    void load_from_file(const string& filename)
    {
        ifstream file(filename);
        if (!file.is_open()) return;

        string line;
        int row = 0;

        while (getline(file, line))
        {
            line = trim_copy(line);
            if (line.empty()) continue;

            if (row == 0) { row++; continue; } // header

            // 11 columns
            string cols[11];
            stringstream ss(line);
            for (int i = 0; i < 11; i++)
                getline(ss, cols[i], ',');

            bill b;
            b.patient_id   = to_int(trim_copy(cols[0]), -1);
            b.patient_name = trim_copy(cols[1]);
            b.bill_type    = trim_copy(cols[2]);
            b.department   = trim_copy(cols[3]);
            b.sensitivity  = to_int(trim_copy(cols[4]), 0);
            b.created_at   = trim_copy(cols[5]);
            b.paid_at      = trim_copy(cols[6]);
            b.status       = trim_copy(cols[7]);
            b.subtotal     = to_int(trim_copy(cols[8]), 0);
            b.total        = to_int(trim_copy(cols[9]), 0);
            b.items        = string_to_items(trim_copy(cols[10]));

            recompute(b);

            if (b.patient_id > 0)
                bills_by_patient[b.patient_id] = b;

            row++;
        }

        file.close();
    }
};
